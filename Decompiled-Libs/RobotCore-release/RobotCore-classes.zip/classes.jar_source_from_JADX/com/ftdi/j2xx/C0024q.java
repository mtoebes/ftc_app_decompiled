package com.ftdi.j2xx;

/* renamed from: com.ftdi.j2xx.q */
class C0024q {
    public long f171a;

    C0024q() {
    }
}
