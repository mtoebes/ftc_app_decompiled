package com.ftdi.j2xx.ft4222;

/* renamed from: com.ftdi.j2xx.ft4222.d */
class C0012d {
    C0011c f98a;
    byte f99b;
    byte f100c;
    byte[] f101d;

    public C0012d() {
        this.f98a = new C0011c();
        this.f101d = new byte[1];
    }
}
