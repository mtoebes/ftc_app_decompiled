package com.ftdi.j2xx.ft4222;

/* renamed from: com.ftdi.j2xx.ft4222.a */
class C0009a {
    int f79a;
    int f80b;
    int f81c;
    int f82d;
    byte f83e;
}
