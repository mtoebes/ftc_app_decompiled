package com.ftdi.j2xx.ft4222;

/* renamed from: com.ftdi.j2xx.ft4222.e */
class C0013e {
    int[] f102a;
    int[] f103b;
    byte f104c;

    public C0013e() {
        this.f102a = new int[4];
        this.f103b = new int[4];
    }
}
