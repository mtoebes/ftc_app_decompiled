package com.ftdi.j2xx.ft4222;

/* renamed from: com.ftdi.j2xx.ft4222.c */
class C0011c {
    byte f95a;
    byte f96b;
    byte[] f97c;

    public C0011c() {
        this.f97c = new byte[3];
    }
}
