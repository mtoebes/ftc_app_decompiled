package com.ftdi.j2xx;

/* renamed from: com.ftdi.j2xx.r */
class C0025r {
    public byte f172a;
    public byte f173b;
    public byte f174c;
    public byte f175d;

    C0025r() {
    }
}
