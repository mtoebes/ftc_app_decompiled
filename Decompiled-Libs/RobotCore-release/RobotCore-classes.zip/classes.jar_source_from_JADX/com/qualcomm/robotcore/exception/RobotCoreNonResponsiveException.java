package com.qualcomm.robotcore.exception;

public class RobotCoreNonResponsiveException extends RobotCoreException {
    public RobotCoreNonResponsiveException(String message) {
        super(message);
    }
}
