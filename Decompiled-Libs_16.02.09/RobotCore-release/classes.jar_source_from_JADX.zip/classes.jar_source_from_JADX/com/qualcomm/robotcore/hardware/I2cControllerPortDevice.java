package com.qualcomm.robotcore.hardware;

public interface I2cControllerPortDevice {
    I2cController getI2cController();

    int getPort();
}
