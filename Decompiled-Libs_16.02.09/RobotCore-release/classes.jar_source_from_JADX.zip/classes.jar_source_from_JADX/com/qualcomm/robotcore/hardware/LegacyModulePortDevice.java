package com.qualcomm.robotcore.hardware;

public interface LegacyModulePortDevice {
    LegacyModule getLegacyModule();

    int getPort();
}
