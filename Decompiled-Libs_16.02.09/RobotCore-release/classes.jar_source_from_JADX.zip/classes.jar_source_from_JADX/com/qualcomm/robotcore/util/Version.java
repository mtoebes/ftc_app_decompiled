package com.qualcomm.robotcore.util;

public class Version {
    public static final String LIBRARY_VERSION = "16.02.09";

    public static String getLibraryVersion() {
        return LIBRARY_VERSION;
    }
}
