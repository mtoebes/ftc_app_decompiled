package com.qualcomm.ftccommon;

public class CommandList {
    public static final String CMD_INIT_OP_MODE = "CMD_INIT_OP_MODE";
    public static final String CMD_INIT_OP_MODE_RESP = "CMD_INIT_OP_MODE_RESP";
    public static final String CMD_REQUEST_OP_MODE_LIST = "CMD_REQUEST_OP_MODE_LIST";
    public static final String CMD_REQUEST_OP_MODE_LIST_RESP = "CMD_REQUEST_OP_MODE_LIST_RESP";
    public static final String CMD_RESTART_ROBOT = "CMD_RESTART_ROBOT";
    public static final String CMD_RUN_OP_MODE = "CMD_RUN_OP_MODE";
    public static final String CMD_RUN_OP_MODE_RESP = "CMD_RUN_OP_MODE_RESP";
}
