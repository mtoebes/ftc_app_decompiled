package com.qualcomm.ftccommon;

public class Device {
    public static final String MANUFACTURER_ZTE = "zte";
    public static final String MODEL_FOXDA_FL7007 = "FL7007";
    public static final String MODEL_ZTE_SPEED = "N9130";
}
